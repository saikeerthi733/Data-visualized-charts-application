﻿/*****************************************************
 * Assignment: 6                                     *
 * Due Date: Thursday, 29th Nov                      *
 *                                                   *
 * Name: Sai keerthi Tsundupalli (z1836733)          *
 * Partner Name: Komal Thakkar (Z1834925)  *   
 *                                                   *
 ****************************************************/

using System;
using System.Windows.Forms;

namespace Tsundupalli_Assign6
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
