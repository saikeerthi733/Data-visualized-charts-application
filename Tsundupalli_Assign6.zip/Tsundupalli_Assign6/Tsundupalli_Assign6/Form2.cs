﻿/*****************************************************
 * Assignment: 6                                     *
 * Due Date: Thursday, 29th Nov                      *
 *                                                   *
 *  Name: Sai keerthi Tsundupalli (z1836733)          *
 * Partner Name: Komal Thakkar (Z1834925)   *
 *                                                   *
 ****************************************************/

using System.Windows.Forms;

namespace Tsundupalli_Assign6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
    }
}
